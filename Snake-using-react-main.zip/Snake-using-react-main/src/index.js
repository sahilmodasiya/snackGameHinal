import React from 'react';
import ReactDOM from 'react-dom';
import Routing from './components/Routing';

ReactDOM.render(<Routing/>,document.getElementById('root'));