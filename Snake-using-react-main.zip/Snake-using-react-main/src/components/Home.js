import React from 'react';
import Header from './header/Header';

class Home extends React.Component{
    render(){
        return(
            <>
                <Header/>
            </>
        )
    }
};

export default Home;